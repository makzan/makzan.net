//
//  AppDelegate.h
//  Demo6
//
//  Created by Seng Hin Mak on 10/6/14.
//  Copyright (c) 2014 Makzan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

